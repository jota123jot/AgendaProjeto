package CamadaDominioProblema;

import java.io.Serializable;
import java.util.ArrayList;



public class Agenda  implements Serializable{

	private ArrayList<Amigo> listaAmigos= new ArrayList<Amigo>();
	private int posicao;
	
	
	public void Adiciona(Amigo amigo){
		listaAmigos.add(amigo);
		
	}
	
	public int GetPosicao(){
		return this.posicao;
	}
	
	public void SetPosicao(int p){
		this.posicao=p;
	}
	
	
	public void DeletaAmigo(int posicao){
		listaAmigos.remove(posicao);
	}
	
	
	public Amigo GetAmigo(Amigo amigo){
		
		for(int posicao=0;posicao<listaAmigos.size();posicao++){
			Amigo achou=listaAmigos.get(posicao);
			if(achou.GetNome().equals(amigo.GetNome())){
				SetPosicao(posicao);
				return amigo;
			}
			
		}
		return null;
	}
	
	public Amigo GetAmigoDireto(int posicao){
		return listaAmigos.get(posicao);
	}
	
	public int GetQuantidade(){
		return listaAmigos.size();
	}
}
