package CamadaDominioProblema;

public class Amigo extends Agenda {
	private String nome,telefone;
	private int  idade;
	private Endereco endereco;
	
	public void SetNome(String nome){
		this.nome=nome;
	}
	
	public void SetIdade(int Idade){
		this.idade=Idade;
	}
	
	public void SetEndereco(Endereco Endereco){
		this.endereco=Endereco;
	}
	
	public void SetTelefone(String telefone){
		this.telefone=telefone;
	}
	
	public String GetTelefone(){
		return telefone;
	}
	
	public String GetNome(){
		return this.nome;
	}
	

	public int GetIdade(){
		return this.idade;
	}
	
	public Endereco GetEndereco(){
		return this.endereco;
	}
}
