package CamadaGerenciaDados;

import java.io.Serializable;

import CamadaDominioProblema.Amigo;

public class Dado implements Serializable{
	private static final long serialVersionUID = 1L;
	private Amigo amigo;
	public Dado(Amigo amigo){
		
		this.amigo=amigo;
	}
	
	public String GetDado(){
		return amigo.GetNome();
	}
	
	public Amigo GetAmigo(){
		return amigo;
	}
}
