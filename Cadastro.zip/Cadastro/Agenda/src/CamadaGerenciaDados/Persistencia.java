package CamadaGerenciaDados;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import CamadaDominioProblema.Agenda;


public class Persistencia {

	
	
	public void Salvar(Agenda agenda){
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("objs.dat"));
			out.writeObject(agenda);
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	

	
	public Agenda CarregaDados() throws ClassNotFoundException{
		Agenda i=null;
		try {
			ObjectInputStream in1 = new ObjectInputStream(new FileInputStream("objs.dat"));
			 i = (Agenda) in1.readObject();
		
			in1.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		return i;
	}
	
	public Agenda Carrega(){
		Agenda agenda= new Agenda();
		try {
			agenda=CarregaDados();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		return agenda;
	}
	
}
