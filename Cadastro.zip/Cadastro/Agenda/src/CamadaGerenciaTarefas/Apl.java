package CamadaGerenciaTarefas;



import CamadaDominioProblema.Agenda;
import CamadaDominioProblema.Amigo;
import CamadaDominioProblema.Endereco;
import CamadaInterecaoUsuario.EntradaSaida;

public class Apl {
	private Agenda agenda;
	private static int vazio=10;
	private static int sucesso=0;
	private static int saiu=1;
	private static int existe=8;
	private int posicao;
	
	public void SetPosicao(int p){
		this.posicao=p;
	}
	
	public int GetPosicao(){
		return posicao;
	}
	
	public void SetAgenda(Agenda agenda){
		this.agenda=agenda;
	}
	final void Adicionando(Amigo amigo){
		this.agenda.Adiciona(amigo);
	}
	
	final Amigo Pesquisando(String nome){
		for(int posicao=0;posicao<agenda.GetQuantidade();posicao++){
			Amigo amigo=agenda.GetAmigoDireto(posicao);
			if(amigo.GetNome().equals(nome)){
				SetPosicao(posicao);
				return amigo;
			}
		}
		return null;
	}
	
	
	public Agenda GetAgenda(){
		return this.agenda;
	}
	
	
	final Amigo Cadastrando(EntradaSaida ES){
		Amigo amigo= new Amigo();
		Endereco endereco= new Endereco();
		amigo.SetNome(ES.GetNome());
		amigo.SetIdade(ES.GetIdade());
		amigo.SetTelefone(ES.GetTelefone());
		endereco.SetBairro(ES.GetBairro());
		endereco.SetCidade(ES.GetCidade());
		endereco.SetEstado(ES.GetEstado());
		endereco.SetNumero(ES.GetNumero());
		endereco.SetRua(ES.GetRua());
		amigo.SetEndereco(endereco);
		return amigo;
	}
	
	final boolean Excluindo(String nome){
		
		Amigo amigo=Pesquisando(nome);
		if(amigo!=null){
			agenda.DeletaAmigo(GetPosicao());
			return true;
		}
		return false;
		
	}
	
	public void Remover(EntradaSaida ES){
		if(ES.GetOpcao()==3){
			ES.Imprime("Nome:");
			String nome=ES.LerString();
			
			if(Excluindo(nome)){
				Evento(true, ES);
			}else{
				ES.SetOpcao(vazio);
			}
			
		}
		
	}
	
	public Amigo Cadastrar(EntradaSaida ES){
		EntradaSaida ES1= new EntradaSaida();
		if(ES.GetOpcao()==1){
			ES1.Imprime("Nome:");
			ES.SetNome(ES1.LerString());
			if(Pesquisando(ES.GetNome())==null){
				ES1.SetNome(ES.GetNome());
				ES1.Cadastrar();
				Amigo amigo=Cadastrando(ES1);
				Adicionando(amigo);
				Evento(true, ES);
				
			}else{
				ES.SetOpcao(existe);
			}
			
		}
		return null;
	}
	
	
	public void Pesquisar(EntradaSaida ES){
		EntradaSaida ES1= new EntradaSaida();
		boolean achou=false;
		if(ES.GetOpcao()==4){
			ES.Imprime("Nome: ");
			ES.SetNome(ES1.LerString());
			Amigo amigo=Pesquisando(ES.GetNome());
			if(amigo!=null){
				ImprimeAmigo(amigo);
				achou=true;
			}
			
			Evento(achou,ES);
			
		}
		
	}
	
	public void ImprimeEndereco(Endereco endereco){
		EntradaSaida ES= new EntradaSaida();
		ES.Imprime("Numero: "+endereco.GetNumero());
		ES.Imprime("Rua: "+endereco.GetRua());
		ES.Imprime("Bairro: "+endereco.GetBairro());
		ES.Imprime("Cidade: "+endereco.GetCidade());
	}
	
	public void ImprimeAmigo(Amigo amigo){
		EntradaSaida ES= new EntradaSaida();
		ES.Imprime("Nome: "+amigo.GetNome());
		ES.Imprime("Idade: "+amigo.GetIdade());
		ES.Imprime("Telefone: "+amigo.GetTelefone());
		ImprimeEndereco(amigo.GetEndereco());
		ES.Imprime("\n\n");
	}
	
	final void Evento(boolean achou,EntradaSaida ES){
		if(achou){
			ES.SetOpcao(sucesso);
		}else{
			ES.SetOpcao(vazio);
		}
	}
	
	public void Listar(EntradaSaida ES){
		boolean achou=false;
		if(ES.GetOpcao()==2){
			
			for(int posicao=0;posicao<agenda.GetQuantidade();posicao++){
				Amigo amigo=agenda.GetAmigoDireto(posicao);
				if(amigo!=null){
					ImprimeAmigo(amigo);
					achou=true;
				}
				
				
			}
			Evento(achou,ES);
		}
		
	}
	
	public void Detalhes(Amigo amigo){
		ImprimeAmigo(amigo);
	}
	
	public boolean Sair(EntradaSaida ES){
		if(ES.GetOpcao()==5){
			ES.SetOpcao(saiu);
			return true;
		}
		return false;
	}
	
	
	
	
}
