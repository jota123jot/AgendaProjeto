package CamadaInterecaoUsuario;

import java.util.InputMismatchException;
import java.util.Scanner;

public class EntradaSaida {
	private String nome,rua,bairro,cidade,estado,telefone;
	private int Opcao=-1,numero,idade;
	private Scanner sc;
	private static int vazio=10;
	private static int sucesso=0;
	private static int saiu=1;
	private static int existe=8;
	public void Imprime(String mensagem){
		System.out.println(mensagem);
	}
	
	public String LerString(){
		
		
		sc = new Scanner(System.in);
		return sc.nextLine();
	}
	
	public int LerInteiro(){
		boolean repete=false;
		int valor=0;
		while(!repete){
			try{
				sc = new Scanner(System.in);
				valor= sc.nextInt();
				repete=true;
			}catch(InputMismatchException e){
				Imprime("Entrada Invalida!\n Digite Novamente");
				repete=false;
			}
		}
		return valor;
	}
	
	public void LerOpcao(){
		sc=new Scanner(System.in);
		boolean repete=false;
		while(!repete){
			try{
				sc = new Scanner(System.in);
				Opcao= sc.nextInt();
				repete=true;
			}catch(InputMismatchException e){
				Imprime("Entrada Invalida!\n Digite Novamente");
				repete=false;
			}
		}
		
	}
	
	public void SetTelefone(String mensagem){
		this.telefone=mensagem;
	}
	
	public void Menu(){
		System.out.println("1-Cadastrar Amigos");
		System.out.println("2-Listar os amigos");
		System.out.println("3-Remover Amigo");
		System.out.println("4-Pesquisar Amigo");
		System.out.println("5-Sair");
	}
	
	public void MenuCadastro(){
		System.out.println("1-Consultar Por Nome");
		System.out.println("2-Consultar Por Telefone");
		System.out.println("3-Consultar Por Bairro");
		System.out.println("4-Consultar Por Cidade");
		System.out.println("5-Consultar Por Estado");
	}
	
	
	
	public int GetOpcao(){
		return Opcao;
	}
	
	public void SetNome(String nome){
		this.nome=nome;
	}
	
	public void SetIdade(int Idade){
		this.idade=Idade;
	}
	
	
	
	public String GetNome(){
		return this.nome;
	}
	

	public int GetIdade(){
		return this.idade;
	}
	
	public void SetRua(String rua){
		this.rua=rua;
	}

	
	public void SetBairro(String Bairro){
		this.bairro=Bairro;
	}
	
	public void SetCidade(String Cidade){
		this.cidade=Cidade;
	}
	
	public void SetEstado(String Estado){
		this.estado=Estado;
	}
	
	public void SetNumero(int Numero){
		this.numero=Numero;
	}
	
	public String GetRua(){
		return this.rua;
	}
	
	public String GetBairro(){
		return this.bairro;
	}
	
	public String GetCidade(){
		return this.cidade;
	}
	
	public String GetEstado(){
		return this.estado;
	}
	
	public String GetTelefone(){
		return this.telefone;
	}
	public int GetNumero(){
		return this.numero;
	}
	
	public void SetOpcao(int op){
		Opcao=op;
	}
	
	public void Cadastrar(){
	
		Imprime("Idade:");
		SetIdade(LerInteiro());
		Imprime("Telefone:");
		SetTelefone(LerString());
		Imprime("Numero:");
		SetNumero(LerInteiro());
		Imprime("Rua:");
		SetRua(LerString());
		Imprime("Bairro:");
		SetBairro(LerString());
		Imprime("Cidade:");
		SetCidade(LerString());
		Imprime("Estado:");
		SetEstado(LerString());
		
		
	}
	
	public void Status(){
		if(Opcao==vazio){
			Imprime("N�o h� dados oper�veis");
		}else if(Opcao==sucesso){
			Imprime("Opera��o feita com sucesso");
		}else if(Opcao==saiu){
			Imprime("Programa terminado com sucesso");
		}else if(Opcao==existe){
			Imprime("Este usu�rio j� existe");
		}
	}
	
	
	
}

