package CamadaDominioProblema;

import java.io.Serializable;

public class Endereco implements Serializable {
	private String rua,bairro,cidade,estado;
	private int numero;
	
	public void SetRua(String rua){
		this.rua=rua;
	}

	
	public void SetBairro(String Bairro){
		this.bairro=Bairro;
	}
	
	public void SetCidade(String Cidade){
		this.cidade=Cidade;
	}
	
	public void SetEstado(String Estado){
		this.estado=Estado;
	}
	
	public void SetNumero(int Numero){
		this.numero=Numero;
	}
	
	public String GetRua(){
		return this.rua;
	}
	
	public String GetBairro(){
		return this.bairro;
	}
	
	public String GetCidade(){
		return this.cidade;
	}
	
	public String GetEstado(){
		return this.estado;
	}
	
	public int GetNumero(){
		return this.numero;
	}
}
