package CamadaControleTarefas;

import CamadaDominioProblema.Agenda;
import CamadaGerenciaDados.Persistencia;
import CamadaGerenciaTarefas.Apl;
import CamadaInterecaoUsuario.EntradaSaida;

public class Principal {

	public static void main(String[] args) {
		Agenda agenda= new Agenda();
		EntradaSaida ES= new EntradaSaida();
		Persistencia persistencia= new Persistencia();
		Apl usuario= new Apl();
		agenda=persistencia.Carrega();
		usuario.SetAgenda(agenda);
		while(!usuario.Sair(ES)){
			ES.Menu();
			ES.LerOpcao();
			usuario.Cadastrar(ES);
			usuario.Pesquisar(ES);
			usuario.Listar(ES);
			usuario.Remover(ES);
			ES.Status();
		}
		persistencia.Salvar(usuario.GetAgenda());
		ES.Status();
		
		
	}

}
